#ifndef TEST_H
#define TEST_H 

#include "../Enemy.h"
#include "../Global.h"
#include "../Menu.h"
#include "../Player.h"
#include "../PowerUp.h"
#include "../SpecialEnemy.h"
#include "../bullet.h"
#include "../entity.h"
#include "test.h"
#include <SFML/Graphics/Rect.hpp>

int main();
int playerTests();
int enemyTests();


#endif